package snownee.jade.addon.access;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.Mannequin;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SignBlock;
import snownee.jade.JadeClient;
import snownee.jade.api.ITooltip;
import snownee.jade.api.IWailaClientRegistration;
import snownee.jade.api.IWailaPlugin;
import snownee.jade.api.JadeIds;
import snownee.jade.api.WailaPlugin;
import snownee.jade.api.theme.IThemeHelper;
import snownee.jade.api.ui.JadeUI;
import snownee.jade.util.JadeLanguages;

@WailaPlugin
public class AccessibilityPlugin implements IWailaPlugin {
	@Override
	public void registerClient(IWailaClientRegistration registration) {
		registration.registerBlockComponent(new SignProvider(), SignBlock.class);
		registration.markAsClientFeature(JadeIds.ACCESS_SIGN);

		registration.registerBlockComponent(new BlockDetailsProvider(), Block.class);
		registration.registerBlockComponent(new BlockDetailsBodyProvider(), Block.class);
		registration.markAsClientFeature(JadeIds.ACCESS_BLOCK_DETAILS);

		registration.registerBlockComponent(new BlockAmountProvider(), Block.class);
		registration.markAsClientFeature(JadeIds.ACCESS_BLOCK_AMOUNT);

		registration.registerEntityComponent(new EntityDetailsProvider(), Entity.class);
		registration.registerEntityComponent(new EntityDetailsBodyProvider(), Entity.class);
		registration.markAsClientFeature(JadeIds.ACCESS_ENTITY_DETAILS);

		registration.registerEntityComponent(new NpcDescriptionProvider(), Mannequin.class);
		registration.markAsClientFeature(JadeIds.ACCESS_NPC_DESCRIPTION);

		registration.registerEntityComponent(new EntityVariantProvider(), LivingEntity.class);
		registration.markAsClientFeature(JadeIds.ACCESS_ENTITY_VARIANT);

		registration.registerEntityComponent(new HeldItemProvider(), LivingEntity.class);
		registration.markAsClientFeature(JadeIds.ACCESS_HELD_ITEM);

		registration.addEntityVariantMapping(EntityTypes.SHULKER, DataComponents.SHULKER_COLOR);
		registration.addEntityVariantMapping(EntityTypes.VILLAGER, null);
	}

	public static void replaceTitle(ITooltip tooltip, String originalName, String key) {
		String message = tooltip.getString(JadeIds.CORE_OBJECT_NAME);
		key = "jade.access." + key;
		if (!message.isBlank() && JadeUI.hasTranslation(key)) {
			var nameClass = JadeLanguages.INSTANCE.getNameClass(originalName);
			var title = IThemeHelper.get().title(JadeClient.format(key, message, nameClass));
			tooltip.replace(JadeIds.CORE_OBJECT_NAME, title);
		}
	}
}
