package snownee.jade.addon.vanilla;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.camel.Camel;
import net.minecraft.world.entity.animal.equine.AbstractHorse;
import net.minecraft.world.entity.animal.equine.Llama;
import snownee.jade.api.EntityAccessor;
import snownee.jade.api.IEntityComponentProvider;
import snownee.jade.api.ITooltip;
import snownee.jade.api.JadeIds;
import snownee.jade.api.config.IPluginConfig;
import snownee.jade.api.theme.IThemeHelper;
import snownee.jade.overlay.DisplayHelper;

public class HorseStatsProvider implements IEntityComponentProvider {
	public static final HorseStatsProvider INSTANCE = new HorseStatsProvider();

	private static final double MAX_JUMP_HEIGHT = getJumpHeight(AbstractHorse.MAX_JUMP_STRENGTH);
	private static final double MAX_MOVEMENT_SPEED = getSpeed(AbstractHorse.MAX_MOVEMENT_SPEED);

	private static Component switchText(String key, boolean showMax, double value, double max) {
		IThemeHelper t = IThemeHelper.get();
		Component valueText = t.info(DisplayHelper.dfCommas.format(value));
		if (showMax) {
			return Component.translatable(key, Component.translatable("jade.fraction", valueText, DisplayHelper.dfCommas.format(max)));
		} else {
			return Component.translatable(key, valueText);
		}
	}

	private static double getJumpHeight(double jumpStrength) {
		return 4.53680079 * jumpStrength * jumpStrength + 1.61431730 * jumpStrength - 0.22656224;
	}

	private static double getSpeed(double speed) {
		// https://minecraft.wiki/w/Horse#Movement_speed
		// https://github.com/sakura-ryoko/minihud/pull/179
		return speed * 43.171815466666658 - 0.000000339999999;
	}

	@Override
	public void appendTooltip(ITooltip tooltip, EntityAccessor accessor, IPluginConfig config) {
		AbstractHorse horse = (AbstractHorse) accessor.getEntity();
		boolean showMax = accessor.showDetails();
		if (horse instanceof Llama llama) {
			tooltip.add(switchText("jade.llamaStrength", showMax, llama.getStrength(), 5));
			return;
		}
		if (horse instanceof Camel) {
			return;
		}
		if (horse.getAttributes().hasAttribute(Attributes.JUMP_STRENGTH)) {
			double jumpHeight = getJumpHeight(horse.getAttributeBaseValue(Attributes.JUMP_STRENGTH));
			tooltip.add(switchText("jade.horseStat.jump", showMax, jumpHeight, MAX_JUMP_HEIGHT));
		}
		if (horse.getAttributes().hasAttribute(Attributes.MOVEMENT_SPEED)) {
			double speed = getSpeed(horse.getAttributeBaseValue(Attributes.MOVEMENT_SPEED));
			tooltip.add(switchText("jade.horseStat.speed", showMax, speed, MAX_MOVEMENT_SPEED));
		}
	}

	@Override
	public Identifier getUid() {
		return JadeIds.MC_HORSE_STATS;
	}
}
